package com.kamenrider.legends.game

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.kamenrider.legends.combat.CombatSystem
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.tan

class GameRenderer(private val combat: CombatSystem) : GLSurfaceView.Renderer {
    @Volatile var moveX=0f
    @Volatile var moveZ=0f
    private var program=0
    private var pos=0
    private var mvpLoc=0
    private var colorLoc=0
    private val projection=FloatArray(16)
    private val view=FloatArray(16)
    private val model=FloatArray(16)
    private val mvp=FloatArray(16)
    private var last=System.nanoTime()
    private val vertices: FloatBuffer = ByteBuffer.allocateDirect(108*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(
            -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
        )); position(0)
    }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(.28f,.48f,.68f,1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs="attribute vec4 aPos; uniform mat4 uMvp; void main(){gl_Position=uMvp*aPos;}"
        val fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"
        val v=shader(GLES20.GL_VERTEX_SHADER,vs); val f=shader(GLES20.GL_FRAGMENT_SHADER,fs)
        program=GLES20.glCreateProgram().also { GLES20.glAttachShader(it,v); GLES20.glAttachShader(it,f); GLES20.glLinkProgram(it) }
        pos=GLES20.glGetAttribLocation(program,"aPos"); mvpLoc=GLES20.glGetUniformLocation(program,"uMvp")
        colorLoc=GLES20.glGetUniformLocation(program,"uColor")
    }
    private fun shader(type:Int,src:String):Int {
        val s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,src); GLES20.glCompileShader(s); return s
    }
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int) {
        GLES20.glViewport(0,0,w,h)
        Matrix.perspectiveM(projection,0,55f,w.toFloat()/h.coerceAtLeast(1),.1f,100f)
    }
    override fun onDrawFrame(gl:GL10?) {
        val now=System.nanoTime(); val dt=((now-last)/1e9).toFloat(); last=now
        combat.setPlayerPosition(0f,0f); combat.update(dt)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setLookAtM(view,0,0f,4.2f,7f,0f,0f,-1f,0f,1f,0f)
        GLES20.glUseProgram(program)
        vertices.position(0); GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,vertices)
        cube(0f,-.8f,-2f,12f,.1f,12f,.18f,.38f,.2f)
        cube(0f,0f,0f,.55f,1.2f,.35f,.12f,.2f,.9f)
        val snap=combat.snapshot()
        if(snap.enemyHp>0) cube(snap.enemyX,0f,snap.enemyZ,.8f,1.3f,.65f,.75f,.12f,.12f)
        GLES20.glDisableVertexAttribArray(pos)
    }
    private fun cube(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float) {
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz)
        Matrix.multiplyMM(mvp,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,mvp,0)
        GLES20.glUniformMatrix4fv(mvpLoc,1,false,mvp,0); GLES20.glUniform4f(colorLoc,r,g,b,1f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36)
    }
}
