package com.kamenrider.legends.cheat

object CheatManager {
    @Volatile var enabled: Boolean = true
    fun playerHp(current: Long) = if (enabled) Long.MAX_VALUE else current
    fun playerMp(current: Long) = if (enabled) Long.MAX_VALUE else current
    fun playerExp(current: Long) = if (enabled) Long.MAX_VALUE else current
    fun damageToPlayer(current: Long, damage: Long) =
        if (enabled) Long.MAX_VALUE else (current - damage.coerceAtLeast(0)).coerceAtLeast(0)
    fun canSpendMp(current: Long, cost: Long) = enabled || current >= cost
    fun spendMp(current: Long, cost: Long) =
        if (enabled) Long.MAX_VALUE else (current - cost).coerceAtLeast(0)
    fun toggle() { enabled = !enabled }
}
