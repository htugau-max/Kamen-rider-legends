package com.kamenrider.legends.combat

enum class EnemyType { NORMAL, BOSS }
enum class EnemyAction { IDLE, CHASING, ATTACKING, DAMAGED, DEFEATED }
data class Enemy(
    val name: String, val type: EnemyType, var hp: Long, val maxHp: Long,
    val attackPower: Long, var x: Float, var z: Float,
    var action: EnemyAction = EnemyAction.IDLE, var attackCooldown: Float = 1.5f
) {
    val alive get() = hp > 0L
    val hpRatio get() = if (maxHp <= 0) 0f else (hp.toFloat()/maxHp).coerceIn(0f,1f)
}
