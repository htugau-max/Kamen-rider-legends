package com.kamenrider.legends.rider

object RiderDatabase {
    private fun skills(prefix: String) = listOf(
        RiderSkill("${prefix}1","Rider Punch","Powerful close-range strike",20,180),
        RiderSkill("${prefix}2","Rider Kick","High-impact kick",35,280),
        RiderSkill("${prefix}3","Special Attack","Energy attack",50,380),
        RiderSkill("${prefix}4","Finisher","Signature finishing move",80,600)
    )
    val all = listOf(
        Rider("ichigo","Kamen Rider Ichigo",RiderEra.SHOWA,listOf(RiderForm("ichigo_base","Ichigo",skills("i"))),Triple(.15f,.75f,.2f)),
        Rider("black","Kamen Rider Black",RiderEra.SHOWA,listOf(RiderForm("black_base","Black",skills("b"))),Triple(.1f,.1f,.1f)),
        Rider("kuuga","Kamen Rider Kuuga",RiderEra.HEISEI,listOf(RiderForm("kuuga_mighty","Mighty Form",skills("k"))),Triple(.75f,.12f,.12f)),
        Rider("build","Kamen Rider Build",RiderEra.HEISEI,listOf(RiderForm("build_rabbit","RabbitTank",skills("bu")),RiderForm("build_hazard","Hazard",skills("bh"))),Triple(.8f,.12f,.12f)),
        Rider("zeroone","Kamen Rider Zero-One",RiderEra.REIWA,listOf(RiderForm("zeroone_rising","Rising Hopper",skills("z")),RiderForm("zeroone_zero2","Zero-Two",skills("zz"))),Triple(.9f,.8f,.1f)),
        Rider("geats","Kamen Rider Geats",RiderEra.REIWA,listOf(RiderForm("geats_boost","Boost Form",skills("g")),RiderForm("geats_ix","Geats IX",skills("gx"))),Triple(.85f,.15f,.15f))
    )
    fun getById(id: String) = all.firstOrNull { it.id == id }
    fun getByEra(era: RiderEra) = all.filter { it.era == era }
}
