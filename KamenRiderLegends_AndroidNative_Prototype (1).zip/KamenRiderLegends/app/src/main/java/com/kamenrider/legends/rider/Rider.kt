package com.kamenrider.legends.rider

enum class RiderEra { SHOWA, HEISEI, REIWA }
data class RiderSkill(val id: String, val name: String, val description: String, val mpCost: Int, val damage: Int)
data class RiderForm(val id: String, val name: String, val skills: List<RiderSkill>)
data class Rider(val id: String, val name: String, val era: RiderEra, val forms: List<RiderForm>, val color: Triple<Float,Float,Float>)
