package com.kamenrider.legends

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.FrameLayout
import android.opengl.GLSurfaceView
import android.graphics.Color
import com.kamenrider.legends.game.GameRenderer
import com.kamenrider.legends.rider.RiderManager
import com.kamenrider.legends.combat.CombatSystem
import com.kamenrider.legends.cheat.CheatManager

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var renderer: GameRenderer
    private lateinit var combat: CombatSystem
    private lateinit var hud: TextView
    private lateinit var root: FrameLayout
    private val riders=RiderManager()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        combat=CombatSystem(riders)
        root=FrameLayout(this)
        gl=GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            renderer=GameRenderer(combat)
            setRenderer(renderer)
            renderMode=GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        root.addView(gl)
        val panel=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(12,10,12,10)
            setBackgroundColor(0x99000000.toInt())
        }
        hud=TextView(this).apply { setTextColor(Color.WHITE); textSize=14f }
        panel.addView(hud)
        fun row(vararg items: Pair<String,()->Unit>) {
            val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
            items.forEach { (label,action) ->
                line.addView(Button(this).apply { text=label; textSize=10f; setOnClickListener { action(); refresh() } },
                    LinearLayout.LayoutParams(0,52,1f))
            }
            panel.addView(line)
        }
        row("ATTACK" to {combat.attack()},"DODGE" to {combat.dodge()},"COUNTER" to {combat.counter()})
        row("SKILL 1" to {combat.skill(0)},"SKILL 2" to {combat.skill(1)},"SKILL 3" to {combat.skill(2)},"SKILL 4" to {combat.skill(3)})
        row("ULTIMATE" to {combat.ultimate()},"BOSS" to {combat.spawnBoss()},"NORMAL" to {combat.spawnNormal()})
        row("HENSHIN" to {riders.transform()},"CHEAT: ${if(CheatManager.enabled) "ON" else "OFF"}" to {CheatManager.toggle()})
        val wrap=FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.WRAP_CONTENT,Gravity.BOTTOM)
        root.addView(panel,wrap)
        setContentView(root)
        refresh()
        panel.setOnTouchListener { _,_-> refresh(); false }
        val refreshRunnable=object:Runnable {
            override fun run() { if(!isFinishing) { refresh(); hud.postDelayed(this,250) } }
        }
        hud.post(refreshRunnable)
    }
    private fun refresh() {
        if(!::hud.isInitialized) return
        val s=combat.snapshot()
        hud.text="KAMEN RIDER LEGENDS  |  ${riders.selectedRider.name} ${if(riders.isTransformed) "[HENSHIN]" else "[HUMAN]"}\nHP ${if(CheatManager.enabled) "∞" else s.hp}   MP ${if(CheatManager.enabled) "∞" else s.mp}   EXP ${if(CheatManager.enabled) "∞" else s.exp}   COMBO ${s.combo}/5\n${s.enemyName}  HP ${s.enemyHp}/${s.enemyMaxHp}   ${s.message}"
    }
    override fun onPause() { super.onPause(); if(::gl.isInitialized) gl.onPause() }
    override fun onResume() { super.onResume(); if(::gl.isInitialized) gl.onResume() }
}
