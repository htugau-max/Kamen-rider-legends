package com.kamenrider.legends.combat

import com.kamenrider.legends.cheat.CheatManager
import com.kamenrider.legends.rider.RiderManager
import kotlin.math.sqrt

enum class PlayerAction { IDLE, ATTACK, DODGE, COUNTER, SKILL, ULTIMATE, DAMAGED }
data class CombatView(
    val hp: Long, val mp: Long, val exp: Long, val combo: Int,
    val playerAction: PlayerAction, val actionTime: Float,
    val enemyHp: Long, val enemyMaxHp: Long, val enemyName: String,
    val enemyX: Float, val enemyZ: Float, val boss: Boolean,
    val cinematic: Float, val message: String
)

class CombatSystem(private val riders: RiderManager) {
    private val lock = Any()
    private var hp = 1000L
    private var mp = 500L
    private var exp = 0L
    private var enemy = Enemy("Combatant", EnemyType.NORMAL, 1200, 1200, 65, 2.4f, -2.5f)
    private var playerX = 0f
    private var playerZ = 0f
    private var combo = 0
    private var comboWindow = 0f
    private var counterWindow = 0f
    private var dodgeTime = 0f
    private var action = PlayerAction.IDLE
    private var actionTime = 0f
    private var cinematic = 0f
    private var message = "BATTLE START"

    fun snapshot() = synchronized(lock) {
        CombatView(CheatManager.playerHp(hp), CheatManager.playerMp(mp), CheatManager.playerExp(exp),
            combo, action, actionTime, enemy.hp, enemy.maxHp, enemy.name, enemy.x, enemy.z,
            enemy.type == EnemyType.BOSS, cinematic, message)
    }
    fun setPlayerPosition(x: Float, z: Float) = synchronized(lock) { playerX=x; playerZ=z }

    fun attack(): String = synchronized(lock) {
        if (!riders.isTransformed) return@synchronized "Transform first!"
        if (!enemy.alive) return@synchronized "Enemy defeated"
        combo = if (comboWindow > 0f) combo % 5 + 1 else 1
        comboWindow = if (combo == 5) 0f else 1.2f
        val damage = 100L + combo * 45L
        hurtEnemy(damage)
        action=PlayerAction.ATTACK; actionTime=.32f
        message=if(combo==5) "FIVE HIT COMBO!  $damage DMG" else "COMBO $combo/5  $damage DMG"
        message
    }
    fun dodge(): String = synchronized(lock) {
        if (!riders.isTransformed) return@synchronized "Transform first!"
        dodgeTime=.7f; counterWindow=1.0f; action=PlayerAction.DODGE; actionTime=.7f
        message="DODGE! COUNTER WINDOW OPEN"; message
    }
    fun counter(): String = synchronized(lock) {
        if (counterWindow <= 0f) return@synchronized "Dodge first to counter"
        if (!enemy.alive) return@synchronized "No enemy"
        counterWindow=0f; hurtEnemy(450); action=PlayerAction.COUNTER; actionTime=.55f
        message="COUNTER ATTACK!"; message
    }
    fun skill(slot: Int): String = synchronized(lock) {
        if (!riders.isTransformed) return@synchronized "Transform first!"
        val skill = riders.getSkills().getOrNull(slot) ?: return@synchronized "Invalid skill"
        if (!enemy.alive) return@synchronized "No enemy"
        if (!CheatManager.canSpendMp(mp,skill.mpCost.toLong())) return@synchronized "Not enough MP"
        mp=CheatManager.spendMp(mp,skill.mpCost.toLong())
        hurtEnemy(skill.damage.toLong())
        action=PlayerAction.SKILL; actionTime=.65f
        message="${skill.name}!  ${skill.damage} DAMAGE"; message
    }
    fun ultimate(): String = synchronized(lock) {
        if (!riders.isTransformed) return@synchronized "Transform first!"
        if (!enemy.alive) return@synchronized "No enemy"
        val cost=150L
        if (!CheatManager.canSpendMp(mp,cost)) return@synchronized "Not enough MP"
        mp=CheatManager.spendMp(mp,cost)
        hurtEnemy(1200)
        action=PlayerAction.ULTIMATE; actionTime=2.2f; cinematic=2.2f
        message="ULTIMATE FINISHER!"; message
    }
    private fun hurtEnemy(damage: Long) {
        enemy.hp=(enemy.hp-damage.coerceAtLeast(0)).coerceAtLeast(0)
        enemy.action=if(enemy.hp==0L) EnemyAction.DEFEATED else EnemyAction.DAMAGED
        if(enemy.hp==0L) {
            exp += if(enemy.type==EnemyType.BOSS) 5000 else 500
            message="ENEMY DEFEATED! +${if(enemy.type==EnemyType.BOSS) 5000 else 500} EXP"
        }
    }
    fun spawnBoss() = synchronized(lock) {
        enemy=Enemy("Dark General",EnemyType.BOSS,12000,12000,180,3f,-3f)
        message="BOSS BATTLE!"
    }
    fun spawnNormal() = synchronized(lock) {
        enemy=Enemy("Combatant",EnemyType.NORMAL,1200,1200,65,2.4f,-2.5f)
        message="ENEMY APPROACHING"
    }
    fun update(dtRaw: Float) = synchronized(lock) {
        val dt=dtRaw.coerceIn(0f,.05f)
        comboWindow=(comboWindow-dt).coerceAtLeast(0f)
        counterWindow=(counterWindow-dt).coerceAtLeast(0f)
        dodgeTime=(dodgeTime-dt).coerceAtLeast(0f)
        cinematic=(cinematic-dt).coerceAtLeast(0f)
        actionTime=(actionTime-dt).coerceAtLeast(0f)
        if(actionTime==0f && action!=PlayerAction.IDLE) action=PlayerAction.IDLE
        if(!enemy.alive) return@synchronized
        val dx=playerX-enemy.x; val dz=playerZ-enemy.z
        val dist=sqrt(dx*dx+dz*dz).coerceAtLeast(.001f)
        if(dist>1.15f) {
            enemy.action=EnemyAction.CHASING
            enemy.x += dx/dist*dt*.65f
            enemy.z += dz/dist*dt*.65f
        } else {
            enemy.attackCooldown-=dt
            if(enemy.attackCooldown<=0f) {
                enemy.attackCooldown=1.7f
                if(dodgeTime<=0f) {
                    hp=CheatManager.damageToPlayer(hp,enemy.attackPower)
                    action=PlayerAction.DAMAGED; actionTime=.25f
                    message="ENEMY ATTACK! -${enemy.attackPower} HP"
                } else message="ATTACK DODGED!"
            }
        }
    }
}
