package com.kamenrider.legends.rider

class RiderManager {
    var selectedRider: Rider = RiderDatabase.getById("build")!!
        private set
    var selectedForm: RiderForm = selectedRider.forms.first()
        private set
    var isTransformed = true
        private set
    fun selectRider(id: String): Boolean {
        val rider = RiderDatabase.getById(id) ?: return false
        selectedRider = rider; selectedForm = rider.forms.first(); isTransformed = false
        return true
    }
    fun selectForm(id: String): Boolean {
        val form = selectedRider.forms.firstOrNull { it.id == id } ?: return false
        selectedForm = form; isTransformed = false; return true
    }
    fun transform() { isTransformed = true }
    fun untransform() { isTransformed = false }
    fun getSkills() = selectedForm.skills.take(4)
}
